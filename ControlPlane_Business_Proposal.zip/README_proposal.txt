ControlPlane.ai - Business Proposal
===================================

FILES
  ControlPlane_Business_Proposal.pdf   Ready to submit (11 pages). Built directly,
                                       no LaTeX needed.
  proposal.tex                         LaTeX source. SELF-CONTAINED - the charts are
                                       drawn with pgfplots, so there are no external
                                       image dependencies.
  fig_*.png                            The same four charts as images, in case you
                                       want them for slides.
  figs.py / build_pdf.py               Scripts that generated the charts and the PDF.

HOW TO COMPILE THE LATEX (three options)

1. Overleaf (easiest, nothing to install)
   - New Project -> Upload Project -> upload proposal.tex
   - Set the compiler to pdfLaTeX (Menu -> Compiler)
   - Compile twice so the table of contents fills in.

2. Windows with MiKTeX or TeX Live
   pdflatex proposal.tex
   pdflatex proposal.tex        (run twice for the table of contents)

3. Linux server
   sudo dnf install texlive-scheme-medium texlive-pgfplots   # or apt equivalent
   pdflatex proposal.tex && pdflatex proposal.tex

EDITING THE NUMBERS
  Every figure in the document comes from one measured run of the prototype:
    python -m scripts.simulate --n 200 --label      (three times, no wipe between)
    python -m scripts.diagnose --target-fpr 0.15
  If you re-measure, the values to update are in Section 6 of proposal.tex and in
  the coordinate lists inside the tikzpicture blocks.

WHAT IS CLAIMED VS ASSUMED
  Sections 6 and 7 are measured results from the prototype (n=327 labelled rows,
  three pooled runs). Section 8 (market, pricing) is explicitly labelled as stated
  assumptions, and Section 10 lists every limitation. Keep that separation - it is
  the reason the document reads as credible rather than promotional.
