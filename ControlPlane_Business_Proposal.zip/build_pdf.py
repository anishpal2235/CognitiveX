from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate, Paragraph,
                                Spacer, Table, TableStyle, Image, PageBreak,
                                KeepTogether)

BLUE=colors.HexColor("#1c448a"); GREY=colors.HexColor("#5a5f69")
LIGHT=colors.HexColor("#eef2f8"); RED=colors.HexColor("#b02a2a")
GREEN=colors.HexColor("#166e46")

B=ParagraphStyle("b",fontName="Helvetica",fontSize=9.3,leading=13.2,alignment=TA_JUSTIFY,
                 spaceAfter=6,textColor=colors.HexColor("#1a1a1a"))
H1=ParagraphStyle("h1",fontName="Helvetica-Bold",fontSize=13.5,leading=16,textColor=BLUE,
                  spaceBefore=13,spaceAfter=6)
H2=ParagraphStyle("h2",fontName="Helvetica-Bold",fontSize=10.3,leading=13,textColor=BLUE,
                  spaceBefore=9,spaceAfter=4)
BUL=ParagraphStyle("bul",parent=B,leftIndent=14,bulletIndent=4,spaceAfter=3)
CAP=ParagraphStyle("cap",fontName="Helvetica-Oblique",fontSize=7.8,leading=10,
                   textColor=GREY,alignment=TA_CENTER,spaceAfter=8,spaceBefore=2)
TC=ParagraphStyle("tc",fontName="Helvetica",fontSize=7.6,leading=9.6)
TCB=ParagraphStyle("tcb",fontName="Helvetica-Bold",fontSize=7.6,leading=9.6,textColor=BLUE)
NOTE=ParagraphStyle("note",parent=B,fontSize=8.6,leading=11.6,textColor=GREY)

S=[]
def p(t,st=B): S.append(Paragraph(t,st))
def h1(t): S.append(Paragraph(t,H1))
def h2(t): S.append(Paragraph(t,H2))
def sp(h=5): S.append(Spacer(1,h))
def bul(items):
    for i in items: S.append(Paragraph(i,BUL,bulletText="\u2022"))
    sp(4)
def num(items):
    for n,i in enumerate(items,1): S.append(Paragraph(i,BUL,bulletText=f"{n}."))
    sp(4)
def cap(t): S.append(Paragraph(t,CAP))
def img(f,w,capt=None):
    from PIL import Image as PIL
    iw,ih=PIL.open(f).size
    S.append(Image(f,width=w,height=w*ih/iw))
    if capt: cap(capt)
    else: sp(6)

def tbl(rows,widths,wrap=(),head=True,zebra=True,align="LEFT"):
    data=[]
    for r,row in enumerate(rows):
        out=[]
        for c,cell in enumerate(row):
            txt=str(cell)
            if c in wrap or (r==0 and head):
                out.append(Paragraph(txt,TCB if (r==0 and head) else TC))
            else:
                out.append(Paragraph(txt,TC))
        data.append(out)
    t=Table(data,colWidths=widths,hAlign=align)
    st=[("FONT",(0,0),(-1,-1),"Helvetica",7.6),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("VALIGN",(0,0),(-1,-1),"TOP")]
    if head:
        st+=[("LINEABOVE",(0,0),(-1,0),0.9,BLUE),
             ("LINEBELOW",(0,0),(-1,0),0.5,BLUE),
             ("LINEBELOW",(0,-1),(-1,-1),0.9,BLUE)]
        if zebra: st.append(("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,LIGHT]))
    else:
        st+=[("LINEABOVE",(0,0),(-1,0),0.9,BLUE),("LINEBELOW",(0,-1),(-1,-1),0.9,BLUE)]
        if zebra: st.append(("ROWBACKGROUNDS",(0,0),(-1,-1),[colors.white,LIGHT]))
    t.setStyle(TableStyle(st))
    S.append(t); sp(8)

W=A4[0]-2*2.1*cm

# ---------------- COVER ----------------
S.append(Spacer(1,3.0*cm))
p("ControlPlane.ai",ParagraphStyle("t",fontName="Helvetica-Bold",fontSize=30,leading=34,
   textColor=BLUE,alignment=TA_CENTER))
sp(8)
p("A Governance Layer for Enterprise Generative AI",
  ParagraphStyle("t2",fontName="Helvetica",fontSize=15,leading=19,alignment=TA_CENTER))
sp(4)
p("Intercept &rarr; Route &rarr; Check &rarr; Act",
  ParagraphStyle("t3",fontName="Helvetica-Oblique",fontSize=11,leading=15,
                 textColor=GREY,alignment=TA_CENTER))
sp(22)
S.append(Table([[""]],colWidths=[W*0.7],rowHeights=[1],hAlign="CENTER",
         style=TableStyle([("LINEABOVE",(0,0),(-1,0),0.8,GREY)])))
sp(18)
p("Business Proposal and Prototype Evidence",
  ParagraphStyle("t4",fontName="Helvetica-Bold",fontSize=13,leading=16,alignment=TA_CENTER))
sp(3)
p("Round 2 &mdash; Prototype Development",
  ParagraphStyle("t5",fontName="Helvetica",fontSize=10,leading=13,textColor=GREY,alignment=TA_CENTER))
sp(34)

kpi=[[Paragraph("Withhold precision",TCB),Paragraph("Detection lift",TCB),
      Paragraph("Check overhead",TCB),Paragraph("Cost saving",TCB)],
     [Paragraph("<font size=17 color='#1c448a'><b>98.2%</b></font>",TC),
      Paragraph("<font size=17 color='#1c448a'><b>1.58x</b></font>",TC),
      Paragraph("<font size=17 color='#1c448a'><b>13 ms</b></font>",TC),
      Paragraph("<font size=17 color='#1c448a'><b>94.8%</b></font>",TC)],
     [Paragraph("55 of 56 withheld<br/>were genuinely unsafe",TC),
      Paragraph("precision 0.753 vs.<br/>0.477 base rate",TC),
      Paragraph("median inline<br/>85 ms p95",TC),
      Paragraph("vs. frontier-only<br/>counterfactual",TC)]]
t=Table(kpi,colWidths=[W/4.0]*4,hAlign="CENTER")
t.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"CENTER"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),
  ("TOPPADDING",(0,0),(-1,-1),6),("BOTTOMPADDING",(0,0),(-1,-1),6),
  ("LINEABOVE",(0,0),(-1,0),0.9,BLUE),("LINEBELOW",(0,0),(-1,0),0.4,BLUE),
  ("LINEBELOW",(0,-1),(-1,-1),0.9,BLUE),("BACKGROUND",(0,1),(-1,1),LIGHT)]))
S.append(t)
sp(30)
p("Measured on 600 simulated enterprise requests, 327 human/oracle-labelled, across three "
  "independent runs. Full methodology and limitations in Sections 6 and 10.",
  ParagraphStyle("cv",parent=NOTE,alignment=TA_CENTER,fontSize=8.2))
sp(14)
p("Anish Kumar Pal &nbsp;|&nbsp; IIT Bombay &nbsp;|&nbsp; 25m1087@iitb.ac.in",
  ParagraphStyle("cv2",fontName="Helvetica",fontSize=9,alignment=TA_CENTER))
sp(3)
p("26 August 2026",ParagraphStyle("cv3",parent=NOTE,alignment=TA_CENTER,fontSize=8))
S.append(PageBreak())

# ---------------- CONTENTS ----------------
h1("Contents")
toc=[["1","Executive Summary"],["2","The Problem"],["3","Solution Architecture"],
     ["4","What Makes This Defensible"],["5","Reference Deployment"],
     ["6","Measured Results"],["7","Engineering Findings Worth Reporting"],
     ["8","Market and Commercial Model"],["9","Roadmap"],["10","Limitations"],
     ["11","Conclusion"]]
tbl([["#","Section"]]+toc,[1.4*cm,W-1.4*cm],wrap=(1,))

# ---------------- 1 ----------------
h1("1. Executive Summary")
p("Enterprises have deployed generative AI faster than they have deployed the ability to "
  "govern it. A single organisation now runs a customer-facing support assistant, an internal "
  "employee copilot, and decision-support tools inside regulated workflows &mdash; three systems "
  "with different latency budgets, different risk tolerances and different regulatory exposure, "
  "typically consumed through vendor APIs that expose nothing but the input and the output.")
p("<b>ControlPlane.ai is a thin, vendor-neutral layer that sits between any application and any "
  "model.</b> Every call is intercepted, routed to an appropriate model under cost and policy "
  "constraints, scored in real time for performance, cost and responsibility, and then subjected "
  "to a graded action ladder rather than a binary allow/block decision.")
p("The architectural claim that distinguishes this from a content filter is a closed loop: "
  "<b>the scores produced by Check become the reward signal for Route.</b> The system gets "
  "cheaper and safer the more traffic it sees, because routing decisions are trained on observed "
  "safety outcomes rather than on static benchmarks.")
p("We built a working prototype and measured it. On 600 simulated enterprise requests "
  "(327 labelled, three independent runs):")
bul(["<b>98.2%</b> of responses the system withholds are genuinely unsafe (55 of 56; "
     "false-positive rate 0.006). One safe answer was withheld out of 171.",
     "<b>1.58x lift</b> in detection precision over the base rate (0.753 vs. 0.477), "
     "at recall 0.859.",
     "<b>13 ms</b> median inline check overhead (85 ms p95), against a 300 ms design budget.",
     "<b>94.8%</b> cost reduction versus routing all traffic to a frontier model."])
p("We also report what does not work. Under the current detector set, a false-positive rate "
  "below 15% and an unmitigated-leakage rate below 10% <i>are not simultaneously achievable</i>. "
  "Section 6.4 presents this as a measured Pareto frontier rather than a tuning failure. We regard "
  "publishing that frontier as more commercially credible than presenting a single tuned "
  "operating point.")

# ---------------- 2 ----------------
h1("2. The Problem")
h2("2.1 Why one-size-fits-all checking fails")
p("The same enterprise simultaneously operates use cases whose requirements are mutually "
  "incompatible:")
tbl([["Use case","Character","Latency","Risk appetite","Blast radius"],
     ["Support assistant","customer-facing, high volume","800 ms","low","external, reputational"],
     ["Internal copilot","employee-facing, contextual","2,000 ms","moderate","internal only"],
     ["Decision support","regulated, agentic","8,000 ms","near-zero","legal, financial"]],
    [3.3*cm,W-3.3*cm-2.1*cm-2.5*cm-3.4*cm,2.1*cm,2.5*cm,3.4*cm],wrap=(0,1,4))
p("A single global threshold cannot serve all three. Tuned for the lending workflow it makes the "
  "support bot unusable; tuned for the support bot it under-protects the regulated flow. Our "
  "measurements confirm this directly: at identical fused-risk thresholds, observed false-positive "
  "rates ranged from <b>0.048</b> on the internal copilot to <b>0.416</b> on the support "
  "assistant (Section 6.5).")
h2("2.2 Five complexities we designed for")
num(["<b>Risk categories overlap.</b> A fabricated detail about a named person is simultaneously "
     "a hallucination and a privacy incident. We therefore score dimensions independently and fuse "
     "them, rather than classifying into one bucket.",
     "<b>There is no real-time ground truth.</b> The knowledge gaps that cause hallucination are "
     "the same gaps that prevent automated verification. We use uncertainty estimation (semantic "
     "entropy, self-consistency) and retrieval verification against source documents, and we treat "
     "abstention as a first-class outcome rather than a silent pass.",
     "<b>Over-flagging and under-flagging are both liabilities.</b> Alert fatigue produces bypass "
     "behaviour; under-flagging produces exposure. This trade-off must be deliberately priced, "
     "which is why we publish an operating curve.",
     "<b>Multi-turn and agentic risk compounds.</b> Session-level risk accumulates with decay, and "
     "irreversible agentic actions are held for review at a materially lower risk threshold than "
     "reversible text responses.",
     "<b>Regulation moves faster than deployment cycles.</b> Policy is therefore <i>data</i>, not "
     "code &mdash; a versioned, hot-reloadable configuration file owned by a compliance function, "
     "not an engineering release."])

# ---------------- 3 ----------------
h1("3. Solution Architecture")
p("Four stages, each independently useful, deployed as a proxy or a thin SDK so that no "
  "application code changes and no model vendor is privileged.")
h2("3.1 Intercept")
p("An OpenAI-compatible endpoint (POST /v1/chat/completions) captures every call. Because "
  "interception happens at the API boundary, the layer works with any foundation model accessed "
  "over HTTP, including models whose internals are unavailable. Every request carries a governance "
  "envelope: tenant, use case, geography, data classification, and whether the action it triggers "
  "is reversible.")
h2("3.2 Route")
p("A contextual bandit (LinUCB over a 16-dimensional feature space) selects the model. It is "
  "initialised from offline preference data and refined by live feedback. Budget is enforced as a "
  "dual-gradient constraint, so spend is paced against a rolling weekly window rather than "
  "hard-capped mid-week.")
p("Critically, <b>policy filters decide which models are eligible before the bandit chooses among "
  "them.</b> A model without a signed data-processing agreement is not an available arm in the EU; "
  "a model whose maximum data classification is 'internal' cannot be selected for regulated "
  "traffic. Exploration is confined to reversible, non-agentic, non-regulated requests, so learning "
  "never occurs on a lending decision.")
h2("3.3 Check")
p("Seven detectors run concurrently under a deadline, in two tiers. Tier one is cheap and always "
  "runs; tier two is invoked only when tier one raises suspicion above a gate, or when policy "
  "mandates it. This is what keeps median overhead at 13 ms.")
tbl([["Detector","Technique","Detects","Budget"],
     ["Privacy","regex + Luhn, novelty-aware","PII not present in the prompt","8 ms"],
     ["Grounding","TF-IDF / embedding retrieval","claims unsupported by source docs","60 ms"],
     ["Bias","anchored lexical patterns","group generalisation in decisions","6 ms"],
     ["Self-consistency","numeric Jaccard across samples","unstable factual claims","15 ms"],
     ["Semantic entropy","meaning clustering of samples","model uncertainty","120 ms"],
     ["Conversation","decayed session accumulation","compounding multi-turn risk","2 ms"],
     ["Judge","secondary model as evaluator","policy-specific nuance","on demand"]],
    [3.0*cm,5.0*cm,W-3.0*cm-5.0*cm-2.0*cm,2.0*cm],wrap=(1,2))
p("Scores are fused as a blend of a confidence-weighted mean and a weighted maximum. The blend "
  "coefficient is the single most important tuning knob in the system and is exposed in "
  "configuration rather than buried in code: at 0 the score under-reacts to one catastrophic "
  "signal, at 1 any single noisy detector dictates the outcome.")
h2("3.4 Act")
p("A five-rung graded ladder, of which four rungs still deliver a usable answer:")
img("fig_ladder.png",W,"Figure 1. Measured distribution of ladder outcomes across 600 requests.")
tbl([["Rung","User receives","Human involved","Measured share"],
     ["Allow","the response, untouched","no","15.5%"],
     ["Annotate","the response plus caveats","no","30.7%"],
     ["Repair","a corrected response","no","34.8%"],
     ["Escalate","a holding message","<b>yes</b>","8.5%"],
     ["Block","a refusal","no","10.5%"]],
    [3.0*cm,W-3.0*cm-3.4*cm-3.0*cm,3.4*cm,3.0*cm],wrap=(1,))
p("The design conviction here is that <b>correction preserves utility where blocking destroys "
  "it</b>. Blocking teaches users to route around the system. In our measured run, 81% of traffic "
  "received a usable answer while 19% was withheld.")

# ---------------- 4 ----------------
h1("4. What Makes This Defensible")
h2("4.1 Check feeds Route")
p("Detector scores are converted into a scalar reward and fed back to the bandit. A model that "
  "produces ungrounded output on a class of queries loses expected value for that feature vector "
  "and stops being selected for it. Safety outcomes thus shape cost decisions, and the two "
  "objectives stop being in tension.")
h2("4.2 Policy as versioned data")
p("Every decision records the content hash of the policy that produced it, so any past action can "
  "be replayed against the exact rules in force at the time. A compliance owner edits a YAML file "
  "and calls POST /v1/policy/reload; no deployment occurs. Resolution is layered: defaults, then "
  "use case, then geography overlay, then data-classification overlay.")
h2("4.3 Tamper-evident audit trail")
p("Every decision appends a hash-chained audit record. Mutating any historical row breaks the "
  "chain and is detected by GET /v1/audit/verify. This is demonstrable live: editing a row in the "
  "database directly causes verification to fail at that index.")
h2("4.4 Deterministic rules coexist with statistical scoring")
p("Hard rules are regulator-readable and can only <i>increase</i> severity, never relax the "
  "ladder. A statistical score cannot override a compliance floor &mdash; an important property "
  "when explaining the system to an auditor.")

# ---------------- 5 ----------------
h1("5. Reference Deployment")
p("The prototype models a mid-sized enterprise operating three concurrent AI use cases at "
  "approximately 20,000 interactions per week, across four models with differing cost, quality, "
  "residency and data-classification ceilings, and a mix of well-governed and loosely governed "
  "internal knowledge sources.")
tbl([["Model","$/1k in","$/1k out","Latency","Residency","Max data class"],
     ["tiny-fast","0.00005","0.00010","180 ms","any","internal"],
     ["mid-balanced","0.00030","0.00120","520 ms","any","confidential"],
     ["frontier-strong","0.00300","0.01500","1400 ms","IN, US","regulated"],
     ["eu-resident-mid","0.00040","0.00150","600 ms","EU only","regulated"]],
    [3.6*cm,2.2*cm,2.2*cm,2.2*cm,2.4*cm,W-12.6*cm])
p("These parameters are directional assumptions, stated so that results can be interpreted and "
  "challenged. The architecture does not depend on them.")

# ---------------- 6 ----------------
h1("6. Measured Results")
h2("6.1 Method")
p("600 requests were generated across three use cases, three geographies and four data classes. "
  "327 received ground-truth labels from an independent oracle that inspects generated text for "
  "injected unsafe markers, knowledge-base contradictions, and PII not present in the prompt. "
  "<b>Detection is graded only against those labels, never against the detectors themselves.</b> "
  "Results pool three independent runs of one configuration; per-run figures are reported "
  "alongside pooled values.")
h2("6.2 Headline figures")
tbl([["Metric","Definition","Result"],
     ["True unsafe base rate","share of labelled responses genuinely unsafe","0.477"],
     ["<b>Definition A</b>","<i>flagged = repair, escalate or block</i>",""],
     ["Precision","of flagged responses, share genuinely unsafe","<b>0.7528</b>"],
     ["Recall","of unsafe responses, share flagged","0.8590"],
     ["False-positive rate","of safe responses, share flagged","0.2573"],
     ["Lift over base rate","precision divided by base rate","<b>1.58x</b>"],
     ["<b>Definition B</b>","<i>flagged = withheld from the user</i>",""],
     ["Precision","of withheld responses, share genuinely unsafe","<b>0.9821</b>"],
     ["False-positive rate","of safe responses, share withheld","<b>0.0058</b>"],
     ["Recall","of unsafe responses, share withheld","0.3526"],
     ["Unmitigated leakage","unsafe delivered without correction","0.141"],
     ["Calibration error (ECE)","10-bin expected calibration error","0.1648"],
     ["Check overhead","median / p95 inline","13 / 85 ms"],
     ["Cost saving","versus frontier-only counterfactual","94.8%"],
     ["Reviewer load","share of traffic escalated to a human","8.5%"]],
    [4.6*cm,W-4.6*cm-2.6*cm,2.6*cm],wrap=(0,1))
p("We report two definitions deliberately. A five-rung ladder cannot be honestly graded as a "
  "binary classifier: counting 'repair' as a positive penalises the system for successfully "
  "correcting a response it still delivered, while counting it as a negative penalises it for not "
  "escalating something it had already fixed. <b>Definition B is the commercially relevant "
  "number</b> &mdash; it answers 'will this system block my customers?' with: one safe response "
  "in 171.")
h2("6.3 Stability")
tbl([["Run","FPR","Recall","Labelled rows"],
     ["1","0.2542","0.820","109"],["2","0.2295","0.875","109"],
     ["3","0.2941","0.879","109"],
     ["<b>Pooled</b>","<b>0.2573</b>","<b>0.859</b>","<b>327</b>"]],
    [2.6*cm,3.0*cm,3.0*cm,3.4*cm])
p("Run-to-run variation arises because the router explores different models, and a different "
  "model produces different text and therefore different labels. This is a genuine property of an "
  "adaptive system, not measurement noise, and we report the range rather than the best draw.")
p("An earlier configuration exhibited a per-run FPR spread of 0.226 (0.113 to 0.339). Removing an "
  "order-dependent interaction between the reviewer-capacity budget and automated blocking "
  "(Section 7.2) reduced that spread to <b>0.065</b> &mdash; an approximately 3.5x improvement in "
  "reproducibility.")
S.append(PageBreak())
h2("6.4 The operating curve and the Pareto frontier")
p("This is the most important result in the proposal. Sweeping a single threshold across the fused "
  "risk score produces the achievable frontier:")
img("fig_curve.png",W*0.92,"Figure 2. Achievable operating points. The deployed ladder and the "
    "withhold tier are marked. The shaded band is the 15% false-positive-rate target.")
p("Pricing the trade-off explicitly:")
tbl([["Threshold","False-positive rate","Recall","Precision"],
     ["0.25","0.409","0.917","0.671"],["0.30","0.287","0.891","0.739"],
     ["0.35","0.170","0.801","0.812"],["0.40","0.129","0.737","0.839"],
     ["0.50","0.000","0.462","1.000"]],
    [3.4*cm,4.6*cm,3.0*cm,3.0*cm])
p("<b>Under the current detector set, a false-positive rate below 0.15 and an unmitigated-leakage "
  "rate below 0.10 cannot be achieved simultaneously.</b> This is a measured property of the "
  "detectors, not a tuning failure, and it is the quantitative form of the "
  "alert-fatigue-versus-liability tension. A buyer should choose a point on this curve according to "
  "their own cost of a false alarm versus a missed harm; the configurable policy layer exists "
  "precisely so that different use cases can sit at different points.")
h2("6.5 Where false positives concentrate")
tbl([["Segment","n","Safe","FP","FPR"],
     ["support_bot","183","89","37","0.416"],
     ["internal_copilot","108","62","3","<b>0.048</b>"],
     ["credit_decision","36","20","4","0.200"],
     ["support_bot / IN / confidential","117","57","29","<b>0.509</b>"],
     ["support_bot / US / confidential","27","13","8","0.615"],
     ["support_bot / EU / confidential","39","19","0","0.000"]],
    [W-4*2.3*cm,2.3*cm,2.3*cm,2.3*cm,2.3*cm],wrap=(0,))
p("Two segments account for 37 of 44 total false positives. This is an argument for the product, "
  "not against it: a single global threshold would either flood the support assistant with false "
  "alarms or under-protect the lending workflow. Per-use-case ladders are the mechanism by which "
  "one deployment serves both.")
h2("6.6 Which detectors carry signal")
p("For each dimension we measure <i>discrimination</i>: mean score on true positives minus mean "
  "score on false alarms. Only this quantity indicates whether a detector separates genuinely "
  "unsafe content from safe content.")
img("fig_discrim.png",W*0.95,"Figure 3. Per-detector discrimination. Negative values indicate a "
    "detector that fires as hard on safe text as on unsafe text.")
p("Retrieval-based grounding and pattern-based privacy detection carry nearly all of the signal, "
  "and both fire at a mean of exactly 0.000 on responses labelled safe &mdash; they are "
  "high-precision instruments.")
p("<b>Semantic entropy shows negative discrimination</b> (-0.054, consistently negative across six "
  "runs). It fires at 0.838 on false alarms and 0.783 on true positives. Our interpretation is "
  "that it is not broken &mdash; it is measuring the wrong thing for this job. Sample disagreement "
  "is a signal about <i>model reliability on a query</i>, not about <i>the safety of a particular "
  "response</i>. It therefore belongs in Route's reward function, not in a per-response gate. "
  "Section 9 treats this as the highest-value roadmap item.")
h2("6.7 Calibration")
p("The entire ladder consists of thresholds on the fused risk score, so if that score is not "
  "calibrated, every threshold is arbitrary.")
img("fig_calib.png",W*0.62,"Figure 4. Reliability diagram, 10 bins, n=327. ECE 0.1648.")
p("Expected calibration error is <b>0.1648</b> against a target below 0.10. Ordering is broadly "
  "correct and every bin above 0.5 resolves to a 100% observed unsafe rate &mdash; meaning the "
  "score is <i>under</i>-confident at the top, which is the safe direction for an error. One "
  "inversion remains between the 0.1-0.2 and 0.2-0.3 bins. We report the number rather than "
  "claiming the system is well calibrated.")
h2("6.8 Cost and latency")
tbl([["Measure","Observed","Target"],
     ["Spend, 600 requests","$0.2821","&mdash;"],
     ["Frontier-only counterfactual","$5.4000","&mdash;"],
     ["Saving","<b>94.8%</b>","&mdash;"],
     ["End-to-end latency p50 / p95","662 / 1782 ms","&mdash;"],
     ["Check overhead p50 / p95","<b>13 / 85 ms</b>","below 300 ms"]],
    [W-2*4.0*cm,4.0*cm,4.0*cm],wrap=(0,))
p("Overhead is low because detectors run concurrently under a deadline, tier two is gated on "
  "tier-one suspicion, and the retrieval index is fitted once at start-up rather than per request. "
  "The saving is stated against a frontier-only counterfactual on identical traffic; it prices "
  "every request as though the most expensive model had answered, including requests that were "
  "blocked.")

# ---------------- 7 ----------------
h1("7. Engineering Findings Worth Reporting")
h2("7.1 Governance controls can silently contradict each other")
p("The system has two independent controls over withholding: the per-use-case risk ladder, and a "
  "reviewer-capacity budget that caps the fraction of traffic reaching a human. We discovered by "
  "measurement that the budget was silently overriding the ladder &mdash; reversing <b>64 of "
  "600</b> protective decisions, 75% of all intended withholds on the highest-volume flow.")
h2("7.2 Automated actions must never be throttled by a human-capacity budget")
p("The root cause was a category error worth naming, because it is easy to repeat. 'Escalate' "
  "consumes reviewer attention; 'block' is fully automated and consumes none. Both were being "
  "charged against the reviewer budget. Because budget is exhausted by earlier traffic, the "
  "responses arriving after exhaustion were released &mdash; and risk is not ordered in time, so "
  "those were as likely to be the worst cases as the mildest. Responses scoring 0.83 to 0.89 were "
  "delivered.")
p("Exempting automated blocking from the reviewer budget produced:")
tbl([["Measure","Before","After"],
     ["Reversed protective decisions","64","<b>16</b>"],
     ["Block-tier decisions reversed","yes","<b>none</b>"],
     ["Withhold rate","12.3%","19.0%"],
     ["Withhold-tier recall","0.211","<b>0.353</b>"],
     ["Withhold-tier precision","0.973","<b>0.982</b>"],
     ["Reviewer load","12.3% reported","8.5% actual"],
     ["Per-run FPR spread","0.226","<b>0.065</b>"]],
    [W-2*4.0*cm,4.0*cm,4.0*cm],wrap=(0,))
p("The same conflation existed in the metric that was supposed to reveal it: reported 'alert rate' "
  "summed escalations and blocks, so the control and its instrument shared one wrong assumption. "
  "<b>A governance metric must measure the resource its corresponding control actually "
  "consumes.</b> We now report reviewer load and automated block rate separately.")

# ---------------- 8 ----------------
h1("8. Market and Commercial Model")
p("<i>The figures in this section are stated assumptions for the purpose of a business case, not "
  "measured results.</i>",NOTE)
h2("8.1 Why this becomes a budget line")
p("Three forces convert AI governance from a research topic into procurement: regulation attaching "
  "penalties to AI-caused harm; enterprises moving from pilots into customer-facing production; "
  "and multi-model deployments making per-vendor safety tooling unworkable. A governance layer "
  "that is vendor-neutral is the only kind that survives a model migration.")
h2("8.2 Positioning")
tbl([["Alternative","Limitation","Our position"],
     ["Model-vendor safety filters","per-vendor, no portability, no audit trail across models",
      "vendor-neutral, one policy across all models"],
     ["Guardrail libraries","developer-owned, rules in code, no governance surface",
      "compliance-owned policy as versioned data"],
     ["Observability / eval platforms","post-hoc analysis; cannot intervene inline",
      "inline enforcement at 13 ms median"],
     ["In-house build","6 to 12 months, and the hard part is calibration",
      "measured frontier and calibration from day one"]],
    [4.6*cm,(W-4.6*cm)/2,(W-4.6*cm)/2],wrap=(0,1,2))
p("The defensible moat is the feedback loop. A deployment that has seen traffic has a router "
  "trained on its own safety outcomes and a policy history that reflects its own regulatory "
  "posture. That accumulates and does not transfer to a competitor.")
h2("8.3 Pricing (illustrative)")
tbl([["Tier","Volume","Model","Included"],
     ["Pilot","to 50k calls/mo","platform fee","1 use case, audit trail"],
     ["Team","to 1M calls/mo","platform + per-call","3 use cases, geo overlays, dashboard"],
     ["Enterprise","unlimited","annual licence","self-hosted, custom detectors, SSO"]],
    [2.8*cm,3.6*cm,4.0*cm,W-10.4*cm],wrap=(3,))
p("The commercial argument is that the layer can fund itself: at 94.8% routing savings on the "
  "reference workload, cost reduction alone plausibly exceeds the governance fee, so the safety "
  "capability arrives as a by-product of a cost decision. This is the wedge &mdash; cost saving is "
  "measurable in week one, whereas avoided harm is not.")

# ---------------- 9 ----------------
h1("9. Roadmap")
tbl([["Horizon","Item","Rationale"],
     ["Immediate","held-out validation split",
      "thresholds are currently tuned on the rows used to score them"],
     ["Immediate","monotonic recalibration map","closes ECE 0.165 toward the target below 0.10"],
     ["Immediate","per-use-case ladder tuning","two segments hold 37 of 44 false positives"],
     ["Near","semantic entropy into Route reward",
      "removes the only negative-discrimination detector from the gate and strengthens the routing loop"],
     ["Near","per-dimension session history","compounding risk currently re-counts fused risk"],
     ["Near","human-review console","closes the loop from reviewer verdict to detector weights"],
     ["Later","regulatory policy packs","pre-built overlays per jurisdiction and industry"],
     ["Later","agentic action gating","pre-commit checks on tool calls, not just text"]],
    [2.4*cm,5.4*cm,W-7.8*cm],wrap=(1,2))

# ---------------- 10 ----------------
h1("10. Limitations")
p("We state these plainly, because a governance product that overstates its own certainty is "
  "self-refuting.")
num(["<b>No held-out split.</b> Fusion weights and ladder thresholds were tuned on the same "
     "labelled rows used to score them. Reported figures are therefore optimistic in an "
     "unquantified way.",
     "<b>Synthetic ground truth.</b> Labels come from a programmatic oracle, not human reviewers. "
     "The oracle was corrected four times during development; each correction changed the reported "
     "numbers materially.",
     "<b>Adversarial simulation.</b> The mock provider injects unsafe content at a rate far above "
     "production, producing a 0.477 base rate. Absolute rates would differ in production; the "
     "relative comparisons are the meaningful part.",
     "<b>Leakage above target.</b> 14.1% of unsafe responses were delivered without correction. "
     "18 of 22 were hedged but uncorrected rather than passed untouched.",
     "<b>The ladder does not yet outperform a single threshold</b> on Definition A. Its "
     "justification rests on the withhold tier's 0.982 precision.",
     "<b>Reproducibility is bounded.</b> Per-run FPR spans 0.230 to 0.294 under identical "
     "configuration, because the router explores.",
     "<b>Cost saving is a counterfactual</b>, priced with a fixed token proxy, and charges blocked "
     "requests as though they had been answered."])

# ---------------- 11 ----------------
h1("11. Conclusion")
p("The prototype demonstrates the core mechanism end to end: interception at the API boundary, "
  "policy-constrained routing, concurrent inline checking at 13 ms median overhead, and a graded "
  "response ladder whose withhold tier is 98.2% precise. It also produces a measured Pareto "
  "frontier showing which safety guarantees are and are not simultaneously achievable with these "
  "detectors.")
p("We regard the second contribution as the more valuable one. Any vendor can present a tuned "
  "operating point. A governance layer earns trust from a skeptical stakeholder by quantifying its "
  "own error rates, publishing the trade-off it cannot escape, and naming the assumptions that "
  "would change the answer.")
sp(10)
box=Table([[Paragraph("<b>Reproducibility.</b> All figures derive from a runnable prototype: "
  "scripts/simulate.py generates and labels traffic, scripts/diagnose.py produces every table and "
  "curve in Section 6, and GET /v1/metrics exposes the same values live. Pooled results combine "
  "three independent 200-request runs of one configuration; per-run values are reported alongside "
  "every pooled figure.",ParagraphStyle("bx",parent=B,fontSize=8.4,leading=11.4))]],
  colWidths=[W])
box.setStyle(TableStyle([("BOX",(0,0),(-1,-1),0.7,BLUE),("BACKGROUND",(0,0),(-1,-1),LIGHT),
  ("TOPPADDING",(0,0),(-1,-1),8),("BOTTOMPADDING",(0,0),(-1,-1),8),
  ("LEFTPADDING",(0,0),(-1,-1),10),("RIGHTPADDING",(0,0),(-1,-1),10)]))
S.append(box)

# ---------------- render ----------------
def deco(canv,doc):
    canv.saveState()
    if doc.page>1:
        canv.setFont("Helvetica",7.5); canv.setFillColor(GREY)
        canv.drawString(2.1*cm,A4[1]-1.35*cm,"ControlPlane.ai  |  Business Proposal")
        canv.drawRightString(A4[0]-2.1*cm,A4[1]-1.35*cm,str(doc.page))
        canv.setStrokeColor(colors.HexColor("#c8d2e2")); canv.setLineWidth(0.4)
        canv.line(2.1*cm,A4[1]-1.55*cm,A4[0]-2.1*cm,A4[1]-1.55*cm)
        canv.drawCentredString(A4[0]/2,1.2*cm,
            "Round 2 Prototype  |  Anish Kumar Pal  |  measured, n=327 labelled")
    canv.restoreState()

doc=BaseDocTemplate("ControlPlane_Business_Proposal.pdf",pagesize=A4,
    leftMargin=2.1*cm,rightMargin=2.1*cm,topMargin=2.0*cm,bottomMargin=1.9*cm,
    title="ControlPlane.ai - Business Proposal",author="Anish Kumar Pal")
frame=Frame(doc.leftMargin,doc.bottomMargin,doc.width,doc.height,id="n")
doc.addPageTemplates([PageTemplate(id="all",frames=[frame],onPage=deco)])
doc.build(S)
print("PDF built")
