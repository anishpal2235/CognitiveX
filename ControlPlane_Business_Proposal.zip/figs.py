import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BLUE="#1c448a"; RED="#b02a2a"; GREEN="#166e46"; GREY="#5a5f69"
plt.rcParams.update({"font.size":8,"axes.edgecolor":GREY,"axes.labelcolor":"#222",
                     "xtick.color":GREY,"ytick.color":GREY,"font.family":"DejaVu Sans"})

# 1. Operating curve / Pareto frontier
fpr=[0.000,0.129,0.170,0.287,0.409,0.649,0.737,0.801]
rec=[0.462,0.737,0.801,0.891,0.917,0.936,0.974,0.981]
f,ax=plt.subplots(figsize=(6.0,3.1),dpi=200)
ax.plot(fpr,rec,"-o",color=BLUE,ms=3.4,lw=1.5,label="single threshold sweep")
ax.plot([0.2573],[0.859],"s",color=RED,ms=7,label="deployed ladder (Def. A)")
ax.plot([0.0058],[0.3526],"^",color=GREEN,ms=8,label="withhold tier (Def. B)")
ax.axvspan(0,0.15,color=GREEN,alpha=0.07)
ax.text(0.075,0.34,"FPR target",color=GREEN,fontsize=7,ha="center")
ax.set_xlabel("False-positive rate (safe responses flagged)")
ax.set_ylabel("Recall on unsafe")
ax.set_xlim(-0.02,0.85); ax.set_ylim(0.30,1.03)
ax.grid(alpha=0.22); ax.legend(fontsize=7,loc="lower right", frameon=True)
f.tight_layout(); f.savefig("fig_curve.png"); plt.close(f)

# 2. Detector discrimination
dims=["hallucination","compounding","cost","bias","grounding","privacy"]
vals=[-0.054,-0.018,0.038,0.129,0.286,0.302]
cols=[RED if v<0 else BLUE for v in vals]
f,ax=plt.subplots(figsize=(6.0,2.5),dpi=200)
b=ax.barh(dims,vals,color=cols,height=0.6)
for r,v in zip(b,vals):
    ax.text(v+(0.008 if v>=0 else -0.008), r.get_y()+r.get_height()/2,
            f"{v:+.3f}", va="center", ha="left" if v>=0 else "right", fontsize=7)
ax.axvline(0,color=GREY,lw=0.8)
ax.set_xlabel("Discrimination (mean on true positives minus mean on false alarms)")
ax.set_xlim(-0.13,0.38); ax.grid(axis="x",alpha=0.22)
f.tight_layout(); f.savefig("fig_discrim.png"); plt.close(f)

# 3. Calibration
mr=[0.010,0.162,0.242,0.341,0.461,0.541,0.653,0.744,0.849,0.946]
ob=[0.075,0.233,0.101,0.471,0.662,1.0,1.0,1.0,1.0,1.0]
f,ax=plt.subplots(figsize=(4.2,3.0),dpi=200)
ax.plot([0,1],[0,1],"--",color=GREY,lw=1,label="perfect calibration")
ax.plot(mr,ob,"-o",color=BLUE,ms=3.4,lw=1.5,label="measured, n=327")
ax.set_xlabel("Mean predicted risk"); ax.set_ylabel("Observed unsafe rate")
ax.set_xlim(0,1); ax.set_ylim(0,1.04); ax.grid(alpha=0.22)
ax.legend(fontsize=7,loc="lower right")
f.tight_layout(); f.savefig("fig_calib.png"); plt.close(f)

# 4. Action ladder mix
lab=["allow","annotate","repair","escalate","block"]
val=[15.5,30.7,34.8,8.5,10.5]
col=[GREEN,"#4a7fbf",BLUE,"#c98b1b",RED]
f,ax=plt.subplots(figsize=(6.0,1.5),dpi=200)
left=0
for l,v,c in zip(lab,val,col):
    ax.barh([0],[v],left=left,color=c,height=0.5)
    ax.text(left+v/2,0,f"{l}\n{v}%",ha="center",va="center",fontsize=7,
            color="white" if c!="#c98b1b" else "#222")
    left+=v
ax.set_xlim(0,100); ax.axis("off")
ax.annotate("", xy=(0,-0.42), xytext=(81,-0.42), arrowprops=dict(arrowstyle="|-|",lw=0.8,color=GREEN))
ax.text(40,-0.62,"81% receive a usable answer",ha="center",fontsize=7,color=GREEN)
ax.annotate("", xy=(81,-0.42), xytext=(100,-0.42), arrowprops=dict(arrowstyle="|-|",lw=0.8,color=RED))
ax.text(90.5,-0.62,"19% withheld",ha="center",fontsize=7,color=RED)
ax.set_ylim(-0.8,0.4)
f.tight_layout(); f.savefig("fig_ladder.png"); plt.close(f)
print("figures OK")
